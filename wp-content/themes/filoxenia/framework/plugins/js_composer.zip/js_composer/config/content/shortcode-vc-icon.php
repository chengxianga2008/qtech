<?php
require_once "vc-icon-element.php";
return vc_icon_element_params();
